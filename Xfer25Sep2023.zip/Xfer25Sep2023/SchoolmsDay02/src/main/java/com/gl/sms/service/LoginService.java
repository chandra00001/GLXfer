package com.gl.sms.service;

import com.gl.sms.model.Login;

public interface LoginService {
	
	public boolean validateLoginSvc(Login login);

}
